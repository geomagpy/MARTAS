#! /usr/bin/env python

import wx
from magpy.gui.magpy_gui import MagPyApp

app = MagPyApp(0)
app.MainLoop()
