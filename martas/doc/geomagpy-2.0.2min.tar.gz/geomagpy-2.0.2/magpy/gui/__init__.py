# -*- coding: utf-8 -*-
"""
GUI modules

:copyright:
    The MagPy Development Team
"""

#from magpy.stream import *
