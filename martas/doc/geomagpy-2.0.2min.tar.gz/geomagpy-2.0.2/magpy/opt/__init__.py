# -*- coding: utf-8 -*-
"""
Optional tools

:copyright:
    The MagPy Development Team
"""

# import order matters - NamedTemporaryFile must be one of the first!
from magpy.stream import *
