# -*- coding: utf-8 -*-
"""
Flagging routines for MagPy.

:copyright:
    The MagPy Development Team
"""

